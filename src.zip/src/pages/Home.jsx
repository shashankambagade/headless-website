// src/pages/Home.jsx
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getPageBySlug } from '../api/wp';
import Seo from '../components/Seo';
import LanguageSwitcher from '../components/LanguageSwitcher';
import PageBuilder from '../components/PageBuilder';

export default function Home() {
  const { lang } = useParams();         // 'sv', 'no', or undefined for English
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchHome() {
      setLoading(true);
      try {
        // 1) Always fetch English home first (no lang param)
        const [enPage] = await getPageBySlug('home');
    

        // 2) If a non-English lang is requested, look up its translated slug
        let pageToUse = enPage;
        if (lang && lang !== 'en') {
          const translatedSlug = enPage.translations[lang];
          if (translatedSlug) {
            // fetch the translation by slug + lang
            const [translatedPage] = await getPageBySlug(translatedSlug, lang);
            pageToUse = translatedPage;
          } else {
            console.warn(`⚠️ No translation found for lang="${lang}", falling back to English`);
          }
        }

        // normalize and set state
        setData({
          id: pageToUse.id,
          slug: pageToUse.slug,
          acf: pageToUse.acf || {},
          yoast: pageToUse.yoast_head_json || {},
          lang: pageToUse.lang,
          translations: pageToUse.translations || {}
        });
      } catch (err) {
        console.error('❌ Error fetching home:', err);
        setData(null);
      } finally {
        setLoading(false);
      }
    }

    fetchHome();
  }, [lang]);

    if (!data) return <div className="relative w-full min-h-[90vh] flex items-center justify-center bg-black px-6 lg:px-16 py-16 md:py-32">
  {/* Tailwind loader */}
    <div class="rounded-full h-20 w-20 bg-violet-800 animate-ping"></div>
</div>;
  if (!data)   return <div className="p-8 text-center">Page not found</div>;

  return (
    <>
      <div className="absolute top-8 right-8 z-50 flex items-center space-x-4">
        <Seo yoast={data.yoast} />
        {/* empty slug forces homepage logic in LanguageSwitcher */}
        <LanguageSwitcher
          slug=""
          lang={data.lang}
          translations={data.translations}
        />
      </div>
      <PageBuilder blocks={data.acf.page_builder} />
    </>
  );
}
