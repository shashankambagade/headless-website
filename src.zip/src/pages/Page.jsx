// src/pages/Page.jsx
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getPageBySlug } from '../api/wp';
import Seo from '../components/Seo';
import LanguageSwitcher from '../components/LanguageSwitcher';
import PageBuilder from '../components/PageBuilder';

export default function Page() {
  const { slug, lang } = useParams();   // slug: 'about-us', lang: 'sv' | 'no' | undefined
  const [data, setData] = useState(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    // reset state on slug/lang change
    setData(null);
    setNotFound(false);

    getPageBySlug(slug, lang)
      .then(pages => pages[0] || null)
      .then(page => {
        if (!page) {
          setNotFound(true);
          return;
        }
        setData({
          id: page.id,
          slug: page.slug,
          title: page.title.rendered,
          content: page.content.rendered,
          acf: page.acf || {},
          yoast: page.yoast_head_json || {},
          lang: page.lang,
          translations: page.translations || {}
        });
      })
      .catch(() => {
        setNotFound(true);
      });
  }, [slug, lang]);

  if (notFound) return <div className="relative w-full min-h-[90vh] text-white flex items-center justify-center bg-black px-6 lg:px-16 py-16 md:py-32">Page not found</div>;
  if (!data) return <div className="relative w-full min-h-[90vh] flex items-center justify-center bg-black px-6 lg:px-16 py-16 md:py-32">
         <div class="rounded-full h-20 w-20 bg-violet-800 animate-ping"></div>
    </div>;

  return (
    <>
      <div className="absolute top-8 right-8 z-50 flex items-center space-x-4">
        <Seo yoast={data.yoast} />
        <LanguageSwitcher
          slug={slug}
          lang={data.lang}
          translations={data.translations}
        />
      </div>
      <PageBuilder blocks={data.acf.page_builder} />
    </>
  );
}
