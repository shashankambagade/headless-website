const flags = {
  en: '/gb.svg',
  sv: '/se.svg',
  no: '/da.png',
};

export default function LanguageSwitcher({ slug, lang, translations }) {
  // if slug is falsy OR literally 'home', treat as homepage
  const isHome = !slug || slug === 'home';

  return (
    <div className="flex items-center space-x-2">
      {Object.entries(translations).map(([code, translatedSlug]) => {
        if (!translatedSlug || code === lang) return null;

        // homepage: only prefix the lang code, never use translatedSlug
        if (isHome) {
          const href = code === 'en' ? '/' : `/${code}`;
          return (
            <a key={code} href={href} title={code.toUpperCase()}>
              <img src={flags[code]} alt={code} className="h-5 w-auto" />
            </a>
          );
        }

        // non-home pages: use the actual translated slug
        const href =
          code === 'en'
            ? `/${translations['en']}`          // e.g. "/about-us"
            : `/${code}/${translatedSlug}`;     // e.g. "/sv/om-oss"

        return (
          <a key={code} href={href} title={code.toUpperCase()}>
            <img src={flags[code]} alt={code} className="h-5 w-auto" />
          </a>
        );
      })}
    </div>
  );
}